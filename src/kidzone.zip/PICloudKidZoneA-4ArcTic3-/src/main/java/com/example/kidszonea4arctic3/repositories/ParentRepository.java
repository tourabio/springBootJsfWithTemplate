package com.example.kidszonea4arctic3.repositories;


import com.example.kidszonea4arctic3.models.Parent;
import org.springframework.data.repository.CrudRepository;

public interface ParentRepository extends CrudRepository<Parent, Long> {

}
